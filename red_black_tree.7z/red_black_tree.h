#pragma once

struct rb_tree_node
{
   rb_tree_node* parent;
   rb_tree_node* left;
   rb_tree_node* right;
   int red;
   int key;
   void* info;
};

struct rb_tree
{
   rb_tree_node* root;
   static rb_tree_node* nil;
};

void RightRotate(rb_tree* tree, rb_tree_node* x);
void LeftRotate(rb_tree*tree, rb_tree_node* x);
void BSTInsert(rb_tree* tree, rb_tree_node* x);
rb_tree_node* RBTreeInsert( rb_tree* tree, int key, void* info );
